#!/bin/bash

java -jar simulation.jar $1 $2 $3 $4