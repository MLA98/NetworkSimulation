# ECS-152A

## run.sh is the shell script to run our simulation
- It takes four arguments: ArrivalRate, ServiceRate, MaxBufferSize and distribution time.
- Example to run it: ./run.sh 0.1 1 20 negExp